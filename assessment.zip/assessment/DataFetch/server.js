const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const csv = require('fast-csv');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./database.db');

app.use(express.static(__dirname));


const urls = [
    "https://subbrang.com/shop/wewriteyourmessage/",
    "https://subbrang.com/shop/ekdinaaphamkomiljayenge/",
    "https://subbrang.com/shop/weareinasameboat/",
    "https://subbrang.com/shop/ourtogetherisforever/",
    "https://subbrang.com/shop/sometimesrightplaceisaperson/",
    "https://subbrang.com/shop/youaremyhappyplace/",
    "https://subbrang.com/shop/youhavecaptutredmyheart/",
    "https://subbrang.com/shop/dil-se-dil-tak/",
    "https://subbrang.com/shop/be-gentle-with-yourself/",
    "https://subbrang.com/shop/picture-perfect-smile/",
    "https://subbrang.com/shop/mini-easel-calendar-2024/",
    "https://subbrang.com/shop/hey-there-you-got-this-fridge-magnet/",
    "https://subbrang.com/shop/heartfelt-dua-fridge-magnet-set/",
    "https://subbrang.com/shop/you-are-awesome/",
    "https://subbrang.com/shop/enjoy-every-moment/",
    "https://subbrang.com/shop/enjoy-the-ride/",
    "https://subbrang.com/shop/prioritize-your-peace/",
    "https://subbrang.com/shop/coffee-addiction/",
    "https://subbrang.com/shop/give-yourself-credit-youve-survived-so-much/",
    "https://subbrang.com/shop/watts-up/",
    "https://subbrang.com/shop/find-the-calm-in-the-chaos/",
    "https://subbrang.com/shop/stay-focused/",
    "https://subbrang.com/shop/smile/",
    "https://subbrang.com/shop/you-are-worthy-of-good-things/"
];


app.get('/scrape', async (req, res) => {
    const products = [];

    for (const url of urls) {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const name = $('.product_title.entry-title').text().trim();
        const price = $('.price ins .woocommerce-Price-amount.amount').text().trim().split('₹')[1];
        const category = $('.product_meta .posted_in a').text().trim();
        const description = $('.woocommerce-Tabs-panel--description p').text().trim(); // Modified this line
        const image = $('.woocommerce-product-gallery__image img').attr('src').trim();

        // Ensure all properties are present
        if (name && price && category && description && image) {
            products.push({ name, price, category, description, image });
        }
    }

    db.serialize(() => {
        db.run('DROP TABLE IF EXISTS products'); // Drop the existing table if it exists
        db.run('CREATE TABLE IF NOT EXISTS products (name TEXT, price TEXT, category TEXT, description TEXT, image TEXT)'); // Create the table with the correct columns
    
        db.run('DELETE FROM products', function(err) {
            if (err) {
                return console.error(err.message);
            }
            console.log(`Deleted ${this.changes} rows`);
        });
        const stmt = db.prepare('INSERT INTO products VALUES (?, ?, ?, ?, ?)');
        for (let product of products) {
            stmt.run(product.name, product.price, product.category, product.description, product.image);
        }
        stmt.finalize();
        res.send('Scraping done!');
    });
});

app.get('/download', (req, res) => {
    const filePath = path.join(__dirname, 'products.csv');
    const ws = fs.createWriteStream(filePath);

    db.all('SELECT * FROM products', [], (err, rows) => {
        if (err) {
            throw err;
        }
        csv.write(rows, { headers: true }).pipe(ws).on('finish', function() {
            res.download(filePath, function(err) {
                if (err) {
                    console.error('File download failed:', err);
                } else {
                    console.log('File downloaded at:', filePath);
                }
            });
        });
    });
});
app.listen(5000, () => console.log('Server running on port 5000'));